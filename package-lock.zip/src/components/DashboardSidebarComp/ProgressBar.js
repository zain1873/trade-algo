// import React from 'react';
// import '../DashboardSidebarComp/styles/progressbar.css';

// const CircularProgressBar = ({ percentage, color }) => {
//   const rotation = percentage * 3.6; 
  
//   return (
//     <div className="circular-progress">
//       <div className="outer-circle">
//         <div className="inner-circle">
//           <div className="percentage">
//             {percentage}<span className="percent-symbol">%</span>
//           </div>
//         </div>
//       </div>
      
//       <div 
//         className="progress-circle" 
//         style={{ 
//           '--percentage': percentage,
//           '--color': color 
//         }}
//       ></div>
//     </div>
//   );
// };

// const ProgressBarsDisplay = () => {
//   return (
//     <div className="container mb-5 p-0">
//     <div className="progress_container shadow p-3">
//         <div className="sec_heading ">
//             <h2 className='text-white'>QBTS</h2>

//         </div>
//       <div className="row justify-content-center p-3">
      
//         <div className="col-md-3 text-center">
//           <CircularProgressBar percentage={45} color="#3CD4A0" />
//           <h4 className='text-white'>progress</h4>
//         </div>
//         <div className="col-md-3 text-center">
//           <CircularProgressBar percentage={75} color="#9333EA" />
//           <h4 className='text-white'>Watched</h4>

//         </div>
//         <div className="col-md-3 text-center">
//           <CircularProgressBar percentage={95} color="#F05252" />
//           <h4 className='text-white'>Success rate</h4>

//         </div>
//       </div>
//       </div>
//     </div>
//   );
// };

// export default ProgressBarsDisplay;
import React, { useEffect, useState } from "react";
import "../DashboardSidebarComp/styles/progressbar.css";

const API_URL = "https://5402-119-155-34-189.ngrok-free.app/api/courses/1/levels/";

const CircularProgressBar = ({ percentage, color, label }) => {
  return (
    <div className="col-md-3 text-center">
      <div className="circular-progress">
        <div className="outer-circle">
          <div className="inner-circle">
            <div className="percentage">
              {percentage}
              <span className="percent-symbol">%</span>
            </div>
          </div>
        </div>
        <div
          className="progress-circle"
          style={{
            "--percentage": percentage,
            "--color": color,
          }}
        ></div>
      </div>
      <h4 className="text-white">{label}</h4>
    </div>
  );
};

const ProgressBarsDisplay = () => {
  const [progressData, setProgressData] = useState([]);
  const [courseName, setCourseName] = useState("Loading...");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchProgress = async () => {
      try {
        const response = await fetch(API_URL, {
          method: "GET",
          mode: "cors",
          headers: {
            "ngrok-skip-browser-warning": "true", // ✅ Ngrok bypass
          },
        });

        if (!response.ok) {
          throw new Error("Failed to fetch data");
        }

        const data = await response.json();
        console.log("API Response:", data);

        setCourseName("Stock Trading Basics");
        setProgressData(data);
      } catch (error) {
        console.error("Error fetching progress data:", error);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchProgress();
  }, []);

  return (
    <div className="container mb-5 p-0">
      <div className="progress_container shadow p-3">
        <div className="sec_heading">
          <h2 className="text-white">{courseName}</h2>
        </div>

        <div className="row justify-content-center p-3">
          {loading ? (
            <p className="text-white">Loading progress...</p>
          ) : error ? (
            <p className="text-danger">Error: {error}</p>
          ) : progressData.length > 0 ? (
            progressData.map((level, index) => (
              <CircularProgressBar
                key={level.id}
                percentage={level.progress_percentage}
                color={["#3CD4A0", "#9333EA", "#F05252"][index % 3]}
                label={level.name}
              />
            ))
          ) : (
            <p className="text-white">No progress data available.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProgressBarsDisplay;
